<template>
  <div class="row fundo justify-content">
    <div class="col-lg-3 col-md-3 col-sm-3 col-3"></div>
    <div class="col-lg-1 col-md-1 col-sm-1 col-1">
      <img class="borda" src="/background/fe064ed6-4d4f-4107-81b6-ddcb34d6521c.jpeg" width="100">
    </div>
    <div class="col-lg-4 col-md-4 col-sm-4 col-4 teste">
      AURA <i class="teste2">©1989</i>
    </div>
  </div>
  <div class="row justify-content-center fundo2 ">
    <div class="col-lg-1 col-md-1 col-sm-1 col-1 ">
      <NuxtLink class="btn btn-lg btn-width-defult botao">
        Sistema
      </NuxtLink>
    </div>
    <div class="col-lg-1 col-md-1 col-sm-1 col-1">
      <NuxtLink class="btn btn-lg btn-width-defult botao" >
        Raças
      </NuxtLink>
    </div>
    <div class="col-lg-1 col-md-1 col-sm-1 col-1">
      <NuxtLink to="/magias" class="btn btn-lg btn-width-defult botao" >
        Magias
      </NuxtLink>
    </div>
    <div class="col-lg-1 col-md-1 col-sm-1 col-1">
      <NuxtLink class="btn btn-lg btn-width-defult botao" >
        Monstros
      </NuxtLink>
    </div>
    <div class="col-lg-2 col-md-2 col-sm-2 col-2">
      <NuxtLink class="btn btn-lg btn-width-defult botao" >
        Personagens
      </NuxtLink>
    </div>
  </div>
</template>

<style>
.rpg-header {
  background-color: #222; /* Cor de fundo */
  color: #fff; /* Cor do texto */
  padding: 10px; /* Espaçamento interno */
  display: flex; /* Torna o cabeçalho um contêiner flexível */
  justify-content: space-between; /* Distribui os elementos filhos ao longo do contêiner */
  align-items: center; /* Alinha os elementos filhos verticalmente */
}

.rpg-header .logo {
  font-size: 24px; /* Tamanho da fonte do logo */
  font-weight: bold; /* Negrito */
}

.rpg-header .menu {
  text-align: center; /* Alinha o texto ao centro */
}

.rpg-header .menu ul {
  list-style-type: none; /* Remove os marcadores de lista */
  padding: 0;
  margin: 0;
  display: inline-block; /* Faz a lista ficar separada */
}

.rpg-header .menu ul li {
  display: inline-block; /* Exibe os itens do menu em linha */
  margin-right: 20px; /* Espaçamento entre os itens do menu */
}

.rpg-header .menu ul li a {
  color: #fff; /* Cor do texto dos links */
  text-decoration: none; /* Remove sublinhado dos links */
}
</style>
