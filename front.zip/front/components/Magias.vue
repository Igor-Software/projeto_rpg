<template>
    <&nbsp>
    <div class="container">
        <div class="row g-4 justify-content-center">
            <div class="col-lg-6 col-md-6 col-sm-6 col-6">
                <div class="row justify-content-center ">
                    <img src="/background/Captura de tela de 2024-02-10 22-35-11.png">
                </div>
            </div>
            <div class="g-4 col-lg-6 col-md-6 col-sm-6 col-6">
                <div class="corDaLetra opacidade">
                    <h1> TITULO </h1>
                    cccccccccccccccccccccccccccc
                </div>
            </div>
        </div>
        <&nbsp>
        <div class="row justify-content-center ">
            <div class="col-lg-2 col-md-2 col-sm-2 col-2">
                <NuxtLink class="btn btn-primary btn-lg btn-width-defult" >
                    <i class=" pi pi-arrow-left"> Voltar </i>
                </NuxtLink>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-2"></div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-2">
                <NuxtLink class="btn btn-primary btn-lg btn-width-defult" >
                    Voltar <i class=" pi pi-arrow-right"></i>
                </NuxtLink>
            </div>
        </div>
    </div>
    <Rodape />
</template>