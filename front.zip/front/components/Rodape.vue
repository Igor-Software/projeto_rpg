<template>
    <div class="row">
      <div class="col-lg-6 col-md-6 col-sm-6 col-6">
        <footer class="custom-footer">
          <p>© 2024 Meu Site. Todos os direitos reservados.</p>
        </footer>
      </div>
    </div>
</template>