<template>
  <div class="row">
    <Cabecalho />
  </div>
    &nbsp
    <div class="container ">
      <div class="row justify-content-center contorno">
        <i>
          <h1>Olá, Viajante</h1>
          <p> obrigado por participar do nosso RPG, este site tem como intuito ser uma wiki com informações sobre o RPG contendo tudo oque foi escrito, criado e desenvolvido.</p>
        </i>
        <i> obrigado por fazer parte desta jornada!!</i>
      </div>
    </div>
  <div class="row">
    <Rodape />
  </div>
</template>
