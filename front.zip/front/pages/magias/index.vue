<template>
   <Magias />
</template>