// https://nuxt.com/docs/api/configuration/nuxt-config
export default defineNuxtConfig({
  devtools: { enabled: true },
  css: [
    'bootstrap/dist/css/bootstrap.min.css',
    'primeicons/primeicons.css',
    '~/css/custom.css',
  ],
  build: {
    transpile: ["primevue"]
  },
  components: true,
  modules: ['nuxt-primevue', "@nuxt/image"],
})